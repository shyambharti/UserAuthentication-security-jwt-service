INSERT INTO USER(ID,USERNAME,PASSWORD,EMAIL)VALUES
(101,'user1','pass1','user1@gmail.com'),
(102,'user2','pass2','user2@gmail.com'),
(103,'user3','pass3','user3@gmail.com');